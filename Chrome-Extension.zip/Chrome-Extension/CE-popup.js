let goPOMO = document.querySelector('.go-POMOTODO');

goPOMO.addEventListener("click", go); 
function go(){
    console.log('asd')
    // window.location.href="https://pomotodo.kr";
    window.open('https://POMOTODO.kr/');
}